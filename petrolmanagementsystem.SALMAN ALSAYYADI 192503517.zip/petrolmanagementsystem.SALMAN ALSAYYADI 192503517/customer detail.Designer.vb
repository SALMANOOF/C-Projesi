<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class customer_detail
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtadd1 = New System.Windows.Forms.TextBox
        Me.btnexit = New System.Windows.Forms.Button
        Me.btndelete = New System.Windows.Forms.Button
        Me.btnedit = New System.Windows.Forms.Button
        Me.btnsave = New System.Windows.Forms.Button
        Me.btnadd = New System.Windows.Forms.Button
        Me.lblemail = New System.Windows.Forms.Label
        Me.lblfax = New System.Windows.Forms.Label
        Me.lblphone = New System.Windows.Forms.Label
        Me.lblpin = New System.Windows.Forms.Label
        Me.lblstate = New System.Windows.Forms.Label
        Me.lblcity = New System.Windows.Forms.Label
        Me.lbladd2 = New System.Windows.Forms.Label
        Me.lbladd1 = New System.Windows.Forms.Label
        Me.lblname = New System.Windows.Forms.Label
        Me.lblid = New System.Windows.Forms.Label
        Me.txtmob = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtfax = New System.Windows.Forms.TextBox
        Me.lblper = New System.Windows.Forms.Label
        Me.grpbox = New System.Windows.Forms.GroupBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.txtper = New System.Windows.Forms.TextBox
        Me.txtphone = New System.Windows.Forms.TextBox
        Me.txtpin = New System.Windows.Forms.TextBox
        Me.txtcity = New System.Windows.Forms.TextBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.cmbstate = New System.Windows.Forms.ComboBox
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.txtadd2 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.grpbox.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtadd1
        '
        Me.txtadd1.Location = New System.Drawing.Point(148, 127)
        Me.txtadd1.Name = "txtadd1"
        Me.txtadd1.Size = New System.Drawing.Size(118, 20)
        Me.txtadd1.TabIndex = 3
        '
        'btnexit
        '
        Me.btnexit.BackColor = System.Drawing.Color.Cyan
        Me.btnexit.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(384, 355)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 41)
        Me.btnexit.TabIndex = 16
        Me.btnexit.Text = "EXIT"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'btndelete
        '
        Me.btndelete.BackColor = System.Drawing.Color.Cyan
        Me.btndelete.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(277, 355)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(87, 41)
        Me.btndelete.TabIndex = 15
        Me.btndelete.Text = "DELETE"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'btnedit
        '
        Me.btnedit.BackColor = System.Drawing.Color.Cyan
        Me.btnedit.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnedit.Location = New System.Drawing.Point(177, 355)
        Me.btnedit.Name = "btnedit"
        Me.btnedit.Size = New System.Drawing.Size(75, 41)
        Me.btnedit.TabIndex = 14
        Me.btnedit.Text = "EDIT"
        Me.btnedit.UseVisualStyleBackColor = False
        '
        'btnsave
        '
        Me.btnsave.BackColor = System.Drawing.Color.Cyan
        Me.btnsave.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(96, 355)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 41)
        Me.btnsave.TabIndex = 12
        Me.btnsave.Text = "SAVE"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'btnadd
        '
        Me.btnadd.BackColor = System.Drawing.Color.Cyan
        Me.btnadd.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(6, 355)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 41)
        Me.btnadd.TabIndex = 11
        Me.btnadd.Text = "ADD"
        Me.btnadd.UseVisualStyleBackColor = False
        '
        'lblemail
        '
        Me.lblemail.AutoSize = True
        Me.lblemail.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblemail.Location = New System.Drawing.Point(286, 226)
        Me.lblemail.Name = "lblemail"
        Me.lblemail.Size = New System.Drawing.Size(65, 18)
        Me.lblemail.TabIndex = 9
        Me.lblemail.Text = "Email ID"
        '
        'lblfax
        '
        Me.lblfax.AutoSize = True
        Me.lblfax.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfax.Location = New System.Drawing.Point(286, 176)
        Me.lblfax.Name = "lblfax"
        Me.lblfax.Size = New System.Drawing.Size(61, 18)
        Me.lblfax.TabIndex = 8
        Me.lblfax.Text = "Fax No."
        '
        'lblphone
        '
        Me.lblphone.AutoSize = True
        Me.lblphone.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblphone.Location = New System.Drawing.Point(286, 77)
        Me.lblphone.Name = "lblphone"
        Me.lblphone.Size = New System.Drawing.Size(82, 18)
        Me.lblphone.TabIndex = 7
        Me.lblphone.Text = "Phone No."
        '
        'lblpin
        '
        Me.lblpin.AutoSize = True
        Me.lblpin.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpin.Location = New System.Drawing.Point(286, 30)
        Me.lblpin.Name = "lblpin"
        Me.lblpin.Size = New System.Drawing.Size(73, 18)
        Me.lblpin.TabIndex = 6
        Me.lblpin.Text = "Pin Code"
        '
        'lblstate
        '
        Me.lblstate.AutoSize = True
        Me.lblstate.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstate.Location = New System.Drawing.Point(19, 268)
        Me.lblstate.Name = "lblstate"
        Me.lblstate.Size = New System.Drawing.Size(45, 18)
        Me.lblstate.TabIndex = 5
        Me.lblstate.Text = "State"
        '
        'lblcity
        '
        Me.lblcity.AutoSize = True
        Me.lblcity.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcity.Location = New System.Drawing.Point(19, 226)
        Me.lblcity.Name = "lblcity"
        Me.lblcity.Size = New System.Drawing.Size(35, 18)
        Me.lblcity.TabIndex = 4
        Me.lblcity.Text = "City"
        '
        'lbladd2
        '
        Me.lbladd2.AutoSize = True
        Me.lbladd2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd2.Location = New System.Drawing.Point(19, 175)
        Me.lbladd2.Name = "lbladd2"
        Me.lbladd2.Size = New System.Drawing.Size(120, 18)
        Me.lbladd2.TabIndex = 3
        Me.lbladd2.Text = "Customer Add 1"
        '
        'lbladd1
        '
        Me.lbladd1.AutoSize = True
        Me.lbladd1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd1.Location = New System.Drawing.Point(19, 127)
        Me.lbladd1.Name = "lbladd1"
        Me.lbladd1.Size = New System.Drawing.Size(108, 18)
        Me.lbladd1.TabIndex = 2
        Me.lbladd1.Text = "Customer Add"
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblname.Location = New System.Drawing.Point(19, 80)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(121, 18)
        Me.lblname.TabIndex = 1
        Me.lblname.Text = "Customer Name"
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblid.Location = New System.Drawing.Point(19, 30)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(96, 18)
        Me.lblid.TabIndex = 0
        Me.lblid.Text = "Customer ID"
        '
        'txtmob
        '
        Me.txtmob.Location = New System.Drawing.Point(405, 125)
        Me.txtmob.Name = "txtmob"
        Me.txtmob.Size = New System.Drawing.Size(118, 20)
        Me.txtmob.TabIndex = 9
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(286, 128)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 18)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Mobile No"
        '
        'txtfax
        '
        Me.txtfax.Location = New System.Drawing.Point(405, 174)
        Me.txtfax.Name = "txtfax"
        Me.txtfax.Size = New System.Drawing.Size(118, 20)
        Me.txtfax.TabIndex = 10
        '
        'lblper
        '
        Me.lblper.AutoSize = True
        Me.lblper.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblper.Location = New System.Drawing.Point(286, 268)
        Me.lblper.Name = "lblper"
        Me.lblper.Size = New System.Drawing.Size(118, 18)
        Me.lblper.TabIndex = 25
        Me.lblper.Text = "Contact Person"
        '
        'grpbox
        '
        Me.grpbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.grpbox.Controls.Add(Me.Button1)
        Me.grpbox.Controls.Add(Me.ComboBox1)
        Me.grpbox.Controls.Add(Me.txtper)
        Me.grpbox.Controls.Add(Me.lblper)
        Me.grpbox.Controls.Add(Me.txtmob)
        Me.grpbox.Controls.Add(Me.Label2)
        Me.grpbox.Controls.Add(Me.txtfax)
        Me.grpbox.Controls.Add(Me.txtphone)
        Me.grpbox.Controls.Add(Me.txtpin)
        Me.grpbox.Controls.Add(Me.txtcity)
        Me.grpbox.Controls.Add(Me.txtname)
        Me.grpbox.Controls.Add(Me.cmbstate)
        Me.grpbox.Controls.Add(Me.txtemail)
        Me.grpbox.Controls.Add(Me.txtadd2)
        Me.grpbox.Controls.Add(Me.txtadd1)
        Me.grpbox.Controls.Add(Me.btnexit)
        Me.grpbox.Controls.Add(Me.btndelete)
        Me.grpbox.Controls.Add(Me.btnedit)
        Me.grpbox.Controls.Add(Me.btnsave)
        Me.grpbox.Controls.Add(Me.btnadd)
        Me.grpbox.Controls.Add(Me.lblemail)
        Me.grpbox.Controls.Add(Me.lblfax)
        Me.grpbox.Controls.Add(Me.lblphone)
        Me.grpbox.Controls.Add(Me.lblpin)
        Me.grpbox.Controls.Add(Me.lblstate)
        Me.grpbox.Controls.Add(Me.lblcity)
        Me.grpbox.Controls.Add(Me.lbladd2)
        Me.grpbox.Controls.Add(Me.lbladd1)
        Me.grpbox.Controls.Add(Me.lblname)
        Me.grpbox.Controls.Add(Me.lblid)
        Me.grpbox.Location = New System.Drawing.Point(69, 93)
        Me.grpbox.Name = "grpbox"
        Me.grpbox.Size = New System.Drawing.Size(568, 424)
        Me.grpbox.TabIndex = 10
        Me.grpbox.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Cyan
        Me.Button1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(464, 355)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 41)
        Me.Button1.TabIndex = 26
        Me.Button1.Text = " SHOW"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(148, 30)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 1
        '
        'txtper
        '
        Me.txtper.Location = New System.Drawing.Point(405, 266)
        Me.txtper.Name = "txtper"
        Me.txtper.Size = New System.Drawing.Size(118, 20)
        Me.txtper.TabIndex = 12
        '
        'txtphone
        '
        Me.txtphone.Location = New System.Drawing.Point(405, 75)
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(118, 20)
        Me.txtphone.TabIndex = 8
        '
        'txtpin
        '
        Me.txtpin.Location = New System.Drawing.Point(405, 28)
        Me.txtpin.Name = "txtpin"
        Me.txtpin.Size = New System.Drawing.Size(118, 20)
        Me.txtpin.TabIndex = 7
        '
        'txtcity
        '
        Me.txtcity.Location = New System.Drawing.Point(148, 223)
        Me.txtcity.Name = "txtcity"
        Me.txtcity.Size = New System.Drawing.Size(118, 20)
        Me.txtcity.TabIndex = 5
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(148, 77)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(118, 20)
        Me.txtname.TabIndex = 2
        '
        'cmbstate
        '
        Me.cmbstate.FormattingEnabled = True
        Me.cmbstate.Location = New System.Drawing.Point(148, 262)
        Me.cmbstate.Name = "cmbstate"
        Me.cmbstate.Size = New System.Drawing.Size(121, 21)
        Me.cmbstate.TabIndex = 6
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(405, 226)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(118, 20)
        Me.txtemail.TabIndex = 11
        '
        'txtadd2
        '
        Me.txtadd2.Location = New System.Drawing.Point(148, 173)
        Me.txtadd2.Name = "txtadd2"
        Me.txtadd2.Size = New System.Drawing.Size(118, 20)
        Me.txtadd2.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label1.Location = New System.Drawing.Point(166, -2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(390, 55)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "   Customer Details"
        '
        'customer_detail
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(707, 529)
        Me.Controls.Add(Me.grpbox)
        Me.Controls.Add(Me.Label1)
        Me.Name = "customer_detail"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "petrol managecustomer_detail"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.grpbox.ResumeLayout(False)
        Me.grpbox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtadd1 As System.Windows.Forms.TextBox
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents btnedit As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents lblemail As System.Windows.Forms.Label
    Friend WithEvents lblfax As System.Windows.Forms.Label
    Friend WithEvents lblphone As System.Windows.Forms.Label
    Friend WithEvents lblpin As System.Windows.Forms.Label
    Friend WithEvents lblstate As System.Windows.Forms.Label
    Friend WithEvents lblcity As System.Windows.Forms.Label
    Friend WithEvents lbladd2 As System.Windows.Forms.Label
    Friend WithEvents lbladd1 As System.Windows.Forms.Label
    Friend WithEvents lblname As System.Windows.Forms.Label
    Friend WithEvents lblid As System.Windows.Forms.Label
    Friend WithEvents txtmob As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtfax As System.Windows.Forms.TextBox
    Friend WithEvents lblper As System.Windows.Forms.Label
    Friend WithEvents grpbox As System.Windows.Forms.GroupBox
    Friend WithEvents txtper As System.Windows.Forms.TextBox
    Friend WithEvents txtphone As System.Windows.Forms.TextBox
    Friend WithEvents txtpin As System.Windows.Forms.TextBox
    Friend WithEvents txtcity As System.Windows.Forms.TextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents cmbstate As System.Windows.Forms.ComboBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtadd2 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
