Module Module1
    Public baccount As bank_Account
    Public bdetails As bank_details
    Public bsetting As booth_settings
    Public caccount As customer_account
    Public cdetail As customer_detail
    Public dtransaction As ds
    Public edetails As emplyoees_details
    Public ledger As ledgerdetails
    Public lbricant As lubricants_details
    Public pdetails As product_details
    Public pdetails1 As product_details
    Public pdetail As productstockdetail
    Public porder As product_order
    'Public ptesting As product_testing
    Public suppdetail As supplier_details
    Public suppaccount As supplier_account
    Public stockk As stock
    Public stock1 As stock
    Public ab As about
    Public pdetailss As Supplier_withdraw_pump_bank_detail

    Public cdiposit As customer_diposit_pump_bank_detail
    Public suwithdraw As suppwithrpt
    Public custdi As custdipositrpt
    Public dttt As dttrpt
    Public dtttt As Famtrpt
    Public ppp As prostockrpt
    Public pppp As billcustomer
End Module
