<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class productstockdetail
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.grpbox = New System.Windows.Forms.GroupBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtqty2 = New System.Windows.Forms.TextBox
        Me.lblqty4 = New System.Windows.Forms.Label
        Me.txtdes = New System.Windows.Forms.TextBox
        Me.lbldes = New System.Windows.Forms.Label
        Me.txtunit = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtqty1 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtqty = New System.Windows.Forms.TextBox
        Me.lblqty = New System.Windows.Forms.Label
        Me.txtorderlevel = New System.Windows.Forms.TextBox
        Me.txtrate = New System.Windows.Forms.TextBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.btnadd = New System.Windows.Forms.Button
        Me.lblorderlevel = New System.Windows.Forms.Label
        Me.btnsave = New System.Windows.Forms.Button
        Me.lblrate = New System.Windows.Forms.Label
        Me.btnedit = New System.Windows.Forms.Button
        Me.lblname = New System.Windows.Forms.Label
        Me.btndelete = New System.Windows.Forms.Button
        Me.lblid = New System.Windows.Forms.Label
        Me.btnorder = New System.Windows.Forms.Button
        Me.btnexit = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.grpbox.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(593, 66)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "liter"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(410, 211)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "liter"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(116, 26)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(126, 21)
        Me.ComboBox1.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(248, 165)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 13)
        Me.Label7.TabIndex = 35
        Me.Label7.Text = " Rs/"
        '
        'grpbox
        '
        Me.grpbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.grpbox.Controls.Add(Me.Label7)
        Me.grpbox.Controls.Add(Me.Label6)
        Me.grpbox.Controls.Add(Me.Label5)
        Me.grpbox.Controls.Add(Me.Label4)
        Me.grpbox.Controls.Add(Me.ComboBox1)
        Me.grpbox.Controls.Add(Me.txtqty2)
        Me.grpbox.Controls.Add(Me.lblqty4)
        Me.grpbox.Controls.Add(Me.txtdes)
        Me.grpbox.Controls.Add(Me.lbldes)
        Me.grpbox.Controls.Add(Me.txtunit)
        Me.grpbox.Controls.Add(Me.Label3)
        Me.grpbox.Controls.Add(Me.txtqty1)
        Me.grpbox.Controls.Add(Me.Label2)
        Me.grpbox.Controls.Add(Me.txtqty)
        Me.grpbox.Controls.Add(Me.lblqty)
        Me.grpbox.Controls.Add(Me.txtorderlevel)
        Me.grpbox.Controls.Add(Me.txtrate)
        Me.grpbox.Controls.Add(Me.txtname)
        Me.grpbox.Controls.Add(Me.btnadd)
        Me.grpbox.Controls.Add(Me.lblorderlevel)
        Me.grpbox.Controls.Add(Me.btnsave)
        Me.grpbox.Controls.Add(Me.lblrate)
        Me.grpbox.Controls.Add(Me.btnedit)
        Me.grpbox.Controls.Add(Me.lblname)
        Me.grpbox.Controls.Add(Me.btndelete)
        Me.grpbox.Controls.Add(Me.lblid)
        Me.grpbox.Controls.Add(Me.btnorder)
        Me.grpbox.Controls.Add(Me.btnexit)
        Me.grpbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpbox.Location = New System.Drawing.Point(99, 129)
        Me.grpbox.Name = "grpbox"
        Me.grpbox.Size = New System.Drawing.Size(693, 366)
        Me.grpbox.TabIndex = 9
        Me.grpbox.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(593, 118)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 13)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "liter"
        '
        'txtqty2
        '
        Me.txtqty2.Location = New System.Drawing.Point(272, 204)
        Me.txtqty2.Name = "txtqty2"
        Me.txtqty2.Size = New System.Drawing.Size(113, 20)
        Me.txtqty2.TabIndex = 9
        '
        'lblqty4
        '
        Me.lblqty4.AutoSize = True
        Me.lblqty4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblqty4.Location = New System.Drawing.Point(194, 204)
        Me.lblqty4.Name = "lblqty4"
        Me.lblqty4.Size = New System.Drawing.Size(64, 16)
        Me.lblqty4.TabIndex = 32
        Me.lblqty4.Text = "Quantity"
        '
        'txtdes
        '
        Me.txtdes.Location = New System.Drawing.Point(116, 114)
        Me.txtdes.Name = "txtdes"
        Me.txtdes.Size = New System.Drawing.Size(126, 20)
        Me.txtdes.TabIndex = 3
        '
        'lbldes
        '
        Me.lbldes.AutoSize = True
        Me.lbldes.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldes.Location = New System.Drawing.Point(8, 114)
        Me.lbldes.Name = "lbldes"
        Me.lbldes.Size = New System.Drawing.Size(87, 16)
        Me.lbldes.TabIndex = 30
        Me.lbldes.Text = "Description"
        '
        'txtunit
        '
        Me.txtunit.Location = New System.Drawing.Point(458, 19)
        Me.txtunit.Name = "txtunit"
        Me.txtunit.Size = New System.Drawing.Size(113, 20)
        Me.txtunit.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(299, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(149, 16)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Unit of Measurement"
        '
        'txtqty1
        '
        Me.txtqty1.Location = New System.Drawing.Point(458, 111)
        Me.txtqty1.Name = "txtqty1"
        Me.txtqty1.Size = New System.Drawing.Size(113, 20)
        Me.txtqty1.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(305, 117)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 16)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "Min. Quantity"
        '
        'txtqty
        '
        Me.txtqty.Location = New System.Drawing.Point(458, 63)
        Me.txtqty.Name = "txtqty"
        Me.txtqty.Size = New System.Drawing.Size(113, 20)
        Me.txtqty.TabIndex = 6
        '
        'lblqty
        '
        Me.lblqty.AutoSize = True
        Me.lblqty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblqty.Location = New System.Drawing.Point(305, 66)
        Me.lblqty.Name = "lblqty"
        Me.lblqty.Size = New System.Drawing.Size(100, 16)
        Me.lblqty.TabIndex = 24
        Me.lblqty.Text = "Max. Quantity"
        '
        'txtorderlevel
        '
        Me.txtorderlevel.Location = New System.Drawing.Point(458, 158)
        Me.txtorderlevel.Name = "txtorderlevel"
        Me.txtorderlevel.Size = New System.Drawing.Size(113, 20)
        Me.txtorderlevel.TabIndex = 8
        '
        'txtrate
        '
        Me.txtrate.Location = New System.Drawing.Point(116, 158)
        Me.txtrate.Name = "txtrate"
        Me.txtrate.Size = New System.Drawing.Size(126, 20)
        Me.txtrate.TabIndex = 4
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(116, 75)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(126, 20)
        Me.txtname.TabIndex = 2
        '
        'btnadd
        '
        Me.btnadd.BackColor = System.Drawing.Color.Cyan
        Me.btnadd.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(51, 289)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 37)
        Me.btnadd.TabIndex = 6
        Me.btnadd.Text = "ADD"
        Me.btnadd.UseVisualStyleBackColor = False
        '
        'lblorderlevel
        '
        Me.lblorderlevel.AutoSize = True
        Me.lblorderlevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblorderlevel.Location = New System.Drawing.Point(305, 161)
        Me.lblorderlevel.Name = "lblorderlevel"
        Me.lblorderlevel.Size = New System.Drawing.Size(89, 16)
        Me.lblorderlevel.TabIndex = 4
        Me.lblorderlevel.Text = "Order Level"
        '
        'btnsave
        '
        Me.btnsave.BackColor = System.Drawing.Color.Cyan
        Me.btnsave.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(155, 289)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(76, 37)
        Me.btnsave.TabIndex = 7
        Me.btnsave.Text = "SAVE"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'lblrate
        '
        Me.lblrate.AutoSize = True
        Me.lblrate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblrate.Location = New System.Drawing.Point(6, 170)
        Me.lblrate.Name = "lblrate"
        Me.lblrate.Size = New System.Drawing.Size(98, 16)
        Me.lblrate.TabIndex = 2
        Me.lblrate.Text = "Product Rate"
        '
        'btnedit
        '
        Me.btnedit.BackColor = System.Drawing.Color.Cyan
        Me.btnedit.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnedit.Location = New System.Drawing.Point(251, 289)
        Me.btnedit.Name = "btnedit"
        Me.btnedit.Size = New System.Drawing.Size(74, 37)
        Me.btnedit.TabIndex = 9
        Me.btnedit.Text = "EDIT"
        Me.btnedit.UseVisualStyleBackColor = False
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblname.Location = New System.Drawing.Point(8, 78)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(106, 16)
        Me.lblname.TabIndex = 1
        Me.lblname.Text = "Product Name"
        '
        'btndelete
        '
        Me.btndelete.BackColor = System.Drawing.Color.Cyan
        Me.btndelete.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(342, 289)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(78, 37)
        Me.btndelete.TabIndex = 10
        Me.btndelete.Text = "DELETE"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblid.Location = New System.Drawing.Point(8, 30)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(80, 16)
        Me.lblid.TabIndex = 0
        Me.lblid.Text = "Product ID"
        '
        'btnorder
        '
        Me.btnorder.BackColor = System.Drawing.Color.Cyan
        Me.btnorder.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnorder.Location = New System.Drawing.Point(447, 289)
        Me.btnorder.Name = "btnorder"
        Me.btnorder.Size = New System.Drawing.Size(77, 37)
        Me.btnorder.TabIndex = 11
        Me.btnorder.Text = "SHOW"
        Me.btnorder.UseVisualStyleBackColor = False
        '
        'btnexit
        '
        Me.btnexit.BackColor = System.Drawing.Color.Cyan
        Me.btnexit.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(555, 289)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 37)
        Me.btnexit.TabIndex = 12
        Me.btnexit.Text = "EXIT"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label1.Location = New System.Drawing.Point(286, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(353, 55)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "   Product Details"
        '
        'productstockdetail
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(910, 534)
        Me.Controls.Add(Me.grpbox)
        Me.Controls.Add(Me.Label1)
        Me.Name = "productstockdetail"
        Me.Text = "productstockdetail"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.grpbox.ResumeLayout(False)
        Me.grpbox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents grpbox As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtqty2 As System.Windows.Forms.TextBox
    Friend WithEvents lblqty4 As System.Windows.Forms.Label
    Friend WithEvents txtdes As System.Windows.Forms.TextBox
    Friend WithEvents lbldes As System.Windows.Forms.Label
    Friend WithEvents txtunit As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtqty1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtqty As System.Windows.Forms.TextBox
    Friend WithEvents lblqty As System.Windows.Forms.Label
    Friend WithEvents txtorderlevel As System.Windows.Forms.TextBox
    Friend WithEvents txtrate As System.Windows.Forms.TextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents lblorderlevel As System.Windows.Forms.Label
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents lblrate As System.Windows.Forms.Label
    Friend WithEvents btnedit As System.Windows.Forms.Button
    Friend WithEvents lblname As System.Windows.Forms.Label
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents lblid As System.Windows.Forms.Label
    Friend WithEvents btnorder As System.Windows.Forms.Button
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
