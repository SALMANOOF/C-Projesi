<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ds
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtcm = New System.Windows.Forms.TextBox
        Me.txtsqty = New System.Windows.Forms.TextBox
        Me.txtos = New System.Windows.Forms.TextBox
        Me.txtom = New System.Windows.Forms.TextBox
        Me.lblvariation = New System.Windows.Forms.Label
        Me.lblds = New System.Windows.Forms.Label
        Me.txtcs = New System.Windows.Forms.TextBox
        Me.cmbrate = New System.Windows.Forms.ComboBox
        Me.cmdok = New System.Windows.Forms.Button
        Me.txtvar = New System.Windows.Forms.TextBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.txtdstk = New System.Windows.Forms.TextBox
        Me.lblcs = New System.Windows.Forms.Label
        Me.lblcm = New System.Windows.Forms.Label
        Me.lblprate = New System.Windows.Forms.Label
        Me.lblsqty = New System.Windows.Forms.Label
        Me.lblos = New System.Windows.Forms.Label
        Me.lblom = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.tabctrl = New System.Windows.Forms.TabControl
        Me.Product = New System.Windows.Forms.TabPage
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.txtfamt = New System.Windows.Forms.TextBox
        Me.lblamt = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.txtdebt = New System.Windows.Forms.TextBox
        Me.lbldebit = New System.Windows.Forms.Label
        Me.btnsubmit = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtdamt = New System.Windows.Forms.TextBox
        Me.txtpamt = New System.Windows.Forms.TextBox
        Me.lblpamt = New System.Windows.Forms.Label
        Me.btnexit = New System.Windows.Forms.Button
        Me.cmbunit = New System.Windows.Forms.ComboBox
        Me.lblprod = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tabctrl.SuspendLayout()
        Me.Product.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtcm
        '
        Me.txtcm.Location = New System.Drawing.Point(507, 16)
        Me.txtcm.Name = "txtcm"
        Me.txtcm.Size = New System.Drawing.Size(138, 25)
        Me.txtcm.TabIndex = 41
        '
        'txtsqty
        '
        Me.txtsqty.Location = New System.Drawing.Point(138, 81)
        Me.txtsqty.Name = "txtsqty"
        Me.txtsqty.Size = New System.Drawing.Size(131, 25)
        Me.txtsqty.TabIndex = 39
        '
        'txtos
        '
        Me.txtos.Location = New System.Drawing.Point(138, 50)
        Me.txtos.Name = "txtos"
        Me.txtos.Size = New System.Drawing.Size(131, 25)
        Me.txtos.TabIndex = 38
        '
        'txtom
        '
        Me.txtom.Location = New System.Drawing.Point(138, 19)
        Me.txtom.Name = "txtom"
        Me.txtom.Size = New System.Drawing.Size(131, 25)
        Me.txtom.TabIndex = 37
        '
        'lblvariation
        '
        Me.lblvariation.AutoSize = True
        Me.lblvariation.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblvariation.Location = New System.Drawing.Point(333, 110)
        Me.lblvariation.Name = "lblvariation"
        Me.lblvariation.Size = New System.Drawing.Size(126, 13)
        Me.lblvariation.TabIndex = 52
        Me.lblvariation.Text = "Variation  in Reading"
        '
        'lblds
        '
        Me.lblds.AutoSize = True
        Me.lblds.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblds.Location = New System.Drawing.Point(335, 79)
        Me.lblds.Name = "lblds"
        Me.lblds.Size = New System.Drawing.Size(103, 13)
        Me.lblds.TabIndex = 51
        Me.lblds.Text = "Actual Dip Stock"
        '
        'txtcs
        '
        Me.txtcs.Location = New System.Drawing.Point(507, 50)
        Me.txtcs.Name = "txtcs"
        Me.txtcs.Size = New System.Drawing.Size(138, 25)
        Me.txtcs.TabIndex = 42
        '
        'cmbrate
        '
        Me.cmbrate.FormattingEnabled = True
        Me.cmbrate.Location = New System.Drawing.Point(138, 116)
        Me.cmbrate.Name = "cmbrate"
        Me.cmbrate.Size = New System.Drawing.Size(131, 25)
        Me.cmbrate.TabIndex = 59
        '
        'cmdok
        '
        Me.cmdok.BackColor = System.Drawing.Color.Cyan
        Me.cmdok.Location = New System.Drawing.Point(295, 131)
        Me.cmdok.Name = "cmdok"
        Me.cmdok.Size = New System.Drawing.Size(90, 32)
        Me.cmdok.TabIndex = 54
        Me.cmdok.Text = "OK"
        Me.cmdok.UseVisualStyleBackColor = False
        '
        'txtvar
        '
        Me.txtvar.Location = New System.Drawing.Point(507, 109)
        Me.txtvar.Name = "txtvar"
        Me.txtvar.Size = New System.Drawing.Size(138, 25)
        Me.txtvar.TabIndex = 44
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cmbrate)
        Me.GroupBox3.Controls.Add(Me.cmdok)
        Me.GroupBox3.Controls.Add(Me.txtvar)
        Me.GroupBox3.Controls.Add(Me.txtdstk)
        Me.GroupBox3.Controls.Add(Me.txtcs)
        Me.GroupBox3.Controls.Add(Me.txtcm)
        Me.GroupBox3.Controls.Add(Me.txtsqty)
        Me.GroupBox3.Controls.Add(Me.txtos)
        Me.GroupBox3.Controls.Add(Me.txtom)
        Me.GroupBox3.Controls.Add(Me.lblvariation)
        Me.GroupBox3.Controls.Add(Me.lblds)
        Me.GroupBox3.Controls.Add(Me.lblcs)
        Me.GroupBox3.Controls.Add(Me.lblcm)
        Me.GroupBox3.Controls.Add(Me.lblprate)
        Me.GroupBox3.Controls.Add(Me.lblsqty)
        Me.GroupBox3.Controls.Add(Me.lblos)
        Me.GroupBox3.Controls.Add(Me.lblom)
        Me.GroupBox3.Location = New System.Drawing.Point(42, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(680, 163)
        Me.GroupBox3.TabIndex = 50
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Meter Reading"
        '
        'txtdstk
        '
        Me.txtdstk.Location = New System.Drawing.Point(507, 81)
        Me.txtdstk.Name = "txtdstk"
        Me.txtdstk.Size = New System.Drawing.Size(138, 25)
        Me.txtdstk.TabIndex = 43
        '
        'lblcs
        '
        Me.lblcs.AutoSize = True
        Me.lblcs.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcs.Location = New System.Drawing.Point(335, 43)
        Me.lblcs.Name = "lblcs"
        Me.lblcs.Size = New System.Drawing.Size(85, 13)
        Me.lblcs.TabIndex = 50
        Me.lblcs.Text = "Closing Stock"
        '
        'lblcm
        '
        Me.lblcm.AutoSize = True
        Me.lblcm.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcm.Location = New System.Drawing.Point(333, 13)
        Me.lblcm.Name = "lblcm"
        Me.lblcm.Size = New System.Drawing.Size(84, 13)
        Me.lblcm.TabIndex = 49
        Me.lblcm.Text = "Closing Meter"
        '
        'lblprate
        '
        Me.lblprate.AutoSize = True
        Me.lblprate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblprate.Location = New System.Drawing.Point(17, 121)
        Me.lblprate.Name = "lblprate"
        Me.lblprate.Size = New System.Drawing.Size(82, 13)
        Me.lblprate.TabIndex = 48
        Me.lblprate.Text = "Product Rate"
        '
        'lblsqty
        '
        Me.lblsqty.AutoSize = True
        Me.lblsqty.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsqty.Location = New System.Drawing.Point(15, 86)
        Me.lblsqty.Name = "lblsqty"
        Me.lblsqty.Size = New System.Drawing.Size(83, 13)
        Me.lblsqty.TabIndex = 47
        Me.lblsqty.Text = "Sold Quantity"
        '
        'lblos
        '
        Me.lblos.AutoSize = True
        Me.lblos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblos.Location = New System.Drawing.Point(17, 55)
        Me.lblos.Name = "lblos"
        Me.lblos.Size = New System.Drawing.Size(91, 13)
        Me.lblos.TabIndex = 46
        Me.lblos.Text = "Opening Stock"
        '
        'lblom
        '
        Me.lblom.AutoSize = True
        Me.lblom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblom.Location = New System.Drawing.Point(17, 21)
        Me.lblom.Name = "lblom"
        Me.lblom.Size = New System.Drawing.Size(90, 13)
        Me.lblom.TabIndex = 45
        Me.lblom.Text = "Opening Meter"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 13)
        Me.Label3.TabIndex = 52
        Me.Label3.Text = "Diesel Amount"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox1.Controls.Add(Me.Button5)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.tabctrl)
        Me.GroupBox1.Controls.Add(Me.btnexit)
        Me.GroupBox1.Location = New System.Drawing.Point(-47, 100)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(720, 455)
        Me.GroupBox1.TabIndex = 79
        Me.GroupBox1.TabStop = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Cyan
        Me.Button5.Location = New System.Drawing.Point(224, 416)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 32)
        Me.Button5.TabIndex = 83
        Me.Button5.Text = " REFRESH"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Cyan
        Me.Button4.Location = New System.Drawing.Point(483, 417)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 32)
        Me.Button4.TabIndex = 55
        Me.Button4.Text = " FSHOW"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Cyan
        Me.Button3.Location = New System.Drawing.Point(122, 417)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 32)
        Me.Button3.TabIndex = 54
        Me.Button3.Text = " SHOW1"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'tabctrl
        '
        Me.tabctrl.Controls.Add(Me.Product)
        Me.tabctrl.Location = New System.Drawing.Point(6, -41)
        Me.tabctrl.Name = "tabctrl"
        Me.tabctrl.SelectedIndex = 0
        Me.tabctrl.Size = New System.Drawing.Size(760, 456)
        Me.tabctrl.TabIndex = 21
        '
        'Product
        '
        Me.Product.BackColor = System.Drawing.SystemColors.Control
        Me.Product.Controls.Add(Me.Button2)
        Me.Product.Controls.Add(Me.Button1)
        Me.Product.Controls.Add(Me.txtfamt)
        Me.Product.Controls.Add(Me.lblamt)
        Me.Product.Controls.Add(Me.GroupBox4)
        Me.Product.Controls.Add(Me.btnsubmit)
        Me.Product.Controls.Add(Me.GroupBox3)
        Me.Product.Controls.Add(Me.GroupBox2)
        Me.Product.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Product.Location = New System.Drawing.Point(4, 22)
        Me.Product.Name = "Product"
        Me.Product.Padding = New System.Windows.Forms.Padding(3)
        Me.Product.Size = New System.Drawing.Size(752, 430)
        Me.Product.TabIndex = 0
        Me.Product.Text = "PRODUCT"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Cyan
        Me.Button2.Location = New System.Drawing.Point(473, 386)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(197, 38)
        Me.Button2.TabIndex = 53
        Me.Button2.Text = " DAILY STOCK DESIGN"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Cyan
        Me.Button1.Location = New System.Drawing.Point(76, 392)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(141, 32)
        Me.Button1.TabIndex = 52
        Me.Button1.Text = "STOCK WATCH"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'txtfamt
        '
        Me.txtfamt.Location = New System.Drawing.Point(252, 353)
        Me.txtfamt.Name = "txtfamt"
        Me.txtfamt.Size = New System.Drawing.Size(175, 25)
        Me.txtfamt.TabIndex = 22
        '
        'lblamt
        '
        Me.lblamt.AutoSize = True
        Me.lblamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblamt.Location = New System.Drawing.Point(137, 353)
        Me.lblamt.Name = "lblamt"
        Me.lblamt.Size = New System.Drawing.Size(80, 13)
        Me.lblamt.TabIndex = 22
        Me.lblamt.Text = "Final Amount"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtdebt)
        Me.GroupBox4.Controls.Add(Me.lbldebit)
        Me.GroupBox4.Location = New System.Drawing.Point(337, 184)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(242, 71)
        Me.GroupBox4.TabIndex = 51
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Other Expenses"
        '
        'txtdebt
        '
        Me.txtdebt.Location = New System.Drawing.Point(121, 23)
        Me.txtdebt.Name = "txtdebt"
        Me.txtdebt.Size = New System.Drawing.Size(98, 25)
        Me.txtdebt.TabIndex = 50
        '
        'lbldebit
        '
        Me.lbldebit.AutoSize = True
        Me.lbldebit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldebit.Location = New System.Drawing.Point(11, 23)
        Me.lbldebit.Name = "lbldebit"
        Me.lbldebit.Size = New System.Drawing.Size(81, 13)
        Me.lbldebit.TabIndex = 52
        Me.lbldebit.Text = "other amount"
        '
        'btnsubmit
        '
        Me.btnsubmit.BackColor = System.Drawing.Color.Cyan
        Me.btnsubmit.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsubmit.Location = New System.Drawing.Point(445, 348)
        Me.btnsubmit.Name = "btnsubmit"
        Me.btnsubmit.Size = New System.Drawing.Size(75, 32)
        Me.btnsubmit.TabIndex = 23
        Me.btnsubmit.Text = "SUBMIT"
        Me.btnsubmit.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.TextBox2)
        Me.GroupBox2.Controls.Add(Me.TextBox1)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtdamt)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.txtpamt)
        Me.GroupBox2.Controls.Add(Me.lblpamt)
        Me.GroupBox2.Location = New System.Drawing.Point(60, 175)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(230, 150)
        Me.GroupBox2.TabIndex = 49
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Product Amount"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(125, 120)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(93, 25)
        Me.TextBox2.TabIndex = 56
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(125, 89)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(93, 25)
        Me.TextBox1.TabIndex = 55
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(3, 132)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 13)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = " Speed Petrol"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(5, 94)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 53
        Me.Label4.Text = " Turbo disel"
        '
        'txtdamt
        '
        Me.txtdamt.Location = New System.Drawing.Point(125, 54)
        Me.txtdamt.Name = "txtdamt"
        Me.txtdamt.Size = New System.Drawing.Size(93, 25)
        Me.txtdamt.TabIndex = 51
        '
        'txtpamt
        '
        Me.txtpamt.Location = New System.Drawing.Point(125, 15)
        Me.txtpamt.Name = "txtpamt"
        Me.txtpamt.Size = New System.Drawing.Size(93, 25)
        Me.txtpamt.TabIndex = 47
        '
        'lblpamt
        '
        Me.lblpamt.AutoSize = True
        Me.lblpamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpamt.Location = New System.Drawing.Point(3, 18)
        Me.lblpamt.Name = "lblpamt"
        Me.lblpamt.Size = New System.Drawing.Size(86, 13)
        Me.lblpamt.TabIndex = 48
        Me.lblpamt.Text = "Petrol Amount"
        '
        'btnexit
        '
        Me.btnexit.BackColor = System.Drawing.Color.Cyan
        Me.btnexit.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(318, 417)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(99, 32)
        Me.btnexit.TabIndex = 21
        Me.btnexit.Text = "EXIT"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'cmbunit
        '
        Me.cmbunit.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmbunit.FormattingEnabled = True
        Me.cmbunit.Location = New System.Drawing.Point(255, 59)
        Me.cmbunit.Name = "cmbunit"
        Me.cmbunit.Size = New System.Drawing.Size(130, 21)
        Me.cmbunit.TabIndex = 74
        '
        'lblprod
        '
        Me.lblprod.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblprod.AutoSize = True
        Me.lblprod.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblprod.Location = New System.Drawing.Point(129, 63)
        Me.lblprod.Name = "lblprod"
        Me.lblprod.Size = New System.Drawing.Size(91, 13)
        Me.lblprod.TabIndex = 80
        Me.lblprod.Text = "Select Product"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label1.Location = New System.Drawing.Point(153, -4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(274, 55)
        Me.Label1.TabIndex = 76
        Me.Label1.Text = "   Daily Sales"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(433, 38)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 82
        Me.Label2.Text = "Label2"
        '
        'ds
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(823, 565)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmbunit)
        Me.Controls.Add(Me.lblprod)
        Me.Controls.Add(Me.Label1)
        Me.Name = "ds"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "ds"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.tabctrl.ResumeLayout(False)
        Me.Product.ResumeLayout(False)
        Me.Product.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtcm As System.Windows.Forms.TextBox
    Friend WithEvents txtsqty As System.Windows.Forms.TextBox
    Friend WithEvents txtos As System.Windows.Forms.TextBox
    Friend WithEvents txtom As System.Windows.Forms.TextBox
    Friend WithEvents lblvariation As System.Windows.Forms.Label
    Friend WithEvents lblds As System.Windows.Forms.Label
    Friend WithEvents txtcs As System.Windows.Forms.TextBox
    Friend WithEvents cmbrate As System.Windows.Forms.ComboBox
    Friend WithEvents cmdok As System.Windows.Forms.Button
    Friend WithEvents txtvar As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtdstk As System.Windows.Forms.TextBox
    Friend WithEvents lblcs As System.Windows.Forms.Label
    Friend WithEvents lblcm As System.Windows.Forms.Label
    Friend WithEvents lblprate As System.Windows.Forms.Label
    Friend WithEvents lblsqty As System.Windows.Forms.Label
    Friend WithEvents lblos As System.Windows.Forms.Label
    Friend WithEvents lblom As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents tabctrl As System.Windows.Forms.TabControl
    Friend WithEvents Product As System.Windows.Forms.TabPage
    Friend WithEvents txtfamt As System.Windows.Forms.TextBox
    Friend WithEvents lblamt As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtdebt As System.Windows.Forms.TextBox
    Friend WithEvents lbldebit As System.Windows.Forms.Label
    Friend WithEvents btnsubmit As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtpamt As System.Windows.Forms.TextBox
    Friend WithEvents lblpamt As System.Windows.Forms.Label
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents cmbunit As System.Windows.Forms.ComboBox
    Friend WithEvents lblprod As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtdamt As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
End Class
