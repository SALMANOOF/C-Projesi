<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class emplyoees_details
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtp2 = New System.Windows.Forms.DateTimePicker
        Me.dtp1 = New System.Windows.Forms.DateTimePicker
        Me.cmbstate = New System.Windows.Forms.ComboBox
        Me.txtbsal = New System.Windows.Forms.TextBox
        Me.txtmobile = New System.Windows.Forms.TextBox
        Me.txtphone = New System.Windows.Forms.TextBox
        Me.txtpin = New System.Windows.Forms.TextBox
        Me.txtcity = New System.Windows.Forms.TextBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.cmbdesig = New System.Windows.Forms.ComboBox
        Me.cmbdept = New System.Windows.Forms.ComboBox
        Me.txtadd2 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtadd1 = New System.Windows.Forms.TextBox
        Me.btnexit = New System.Windows.Forms.Button
        Me.btndelete = New System.Windows.Forms.Button
        Me.btnedit = New System.Windows.Forms.Button
        Me.btnsave = New System.Windows.Forms.Button
        Me.btnadd = New System.Windows.Forms.Button
        Me.lbljd = New System.Windows.Forms.Label
        Me.lblsal = New System.Windows.Forms.Label
        Me.lbldesig = New System.Windows.Forms.Label
        Me.lbldept = New System.Windows.Forms.Label
        Me.lbldob = New System.Windows.Forms.Label
        Me.lblmobile = New System.Windows.Forms.Label
        Me.lblphone = New System.Windows.Forms.Label
        Me.lblcity = New System.Windows.Forms.Label
        Me.lbladd2 = New System.Windows.Forms.Label
        Me.lbladd1 = New System.Windows.Forms.Label
        Me.lblname = New System.Windows.Forms.Label
        Me.lblid = New System.Windows.Forms.Label
        Me.lblpin = New System.Windows.Forms.Label
        Me.grpbox = New System.Windows.Forms.GroupBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.lblstate = New System.Windows.Forms.Label
        Me.grpbox.SuspendLayout()
        Me.SuspendLayout()
        '
        'dtp2
        '
        Me.dtp2.Location = New System.Drawing.Point(393, 308)
        Me.dtp2.Name = "dtp2"
        Me.dtp2.Size = New System.Drawing.Size(136, 20)
        Me.dtp2.TabIndex = 14
        '
        'dtp1
        '
        Me.dtp1.Location = New System.Drawing.Point(399, 120)
        Me.dtp1.Name = "dtp1"
        Me.dtp1.Size = New System.Drawing.Size(136, 20)
        Me.dtp1.TabIndex = 10
        '
        'cmbstate
        '
        Me.cmbstate.FormattingEnabled = True
        Me.cmbstate.Location = New System.Drawing.Point(113, 261)
        Me.cmbstate.Name = "cmbstate"
        Me.cmbstate.Size = New System.Drawing.Size(136, 21)
        Me.cmbstate.TabIndex = 6
        '
        'txtbsal
        '
        Me.txtbsal.Location = New System.Drawing.Point(393, 264)
        Me.txtbsal.Name = "txtbsal"
        Me.txtbsal.Size = New System.Drawing.Size(136, 20)
        Me.txtbsal.TabIndex = 13
        '
        'txtmobile
        '
        Me.txtmobile.Location = New System.Drawing.Point(399, 69)
        Me.txtmobile.MaxLength = 11
        Me.txtmobile.Name = "txtmobile"
        Me.txtmobile.Size = New System.Drawing.Size(136, 20)
        Me.txtmobile.TabIndex = 9
        '
        'txtphone
        '
        Me.txtphone.Location = New System.Drawing.Point(399, 29)
        Me.txtphone.MaxLength = 11
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(136, 20)
        Me.txtphone.TabIndex = 8
        '
        'txtpin
        '
        Me.txtpin.Location = New System.Drawing.Point(113, 307)
        Me.txtpin.Name = "txtpin"
        Me.txtpin.Size = New System.Drawing.Size(136, 20)
        Me.txtpin.TabIndex = 7
        '
        'txtcity
        '
        Me.txtcity.Location = New System.Drawing.Point(113, 215)
        Me.txtcity.Name = "txtcity"
        Me.txtcity.Size = New System.Drawing.Size(136, 20)
        Me.txtcity.TabIndex = 5
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(113, 69)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(136, 20)
        Me.txtname.TabIndex = 2
        '
        'cmbdesig
        '
        Me.cmbdesig.FormattingEnabled = True
        Me.cmbdesig.Location = New System.Drawing.Point(393, 215)
        Me.cmbdesig.Name = "cmbdesig"
        Me.cmbdesig.Size = New System.Drawing.Size(136, 21)
        Me.cmbdesig.TabIndex = 12
        '
        'cmbdept
        '
        Me.cmbdept.FormattingEnabled = True
        Me.cmbdept.Location = New System.Drawing.Point(393, 164)
        Me.cmbdept.Name = "cmbdept"
        Me.cmbdept.Size = New System.Drawing.Size(136, 21)
        Me.cmbdept.TabIndex = 11
        '
        'txtadd2
        '
        Me.txtadd2.Location = New System.Drawing.Point(113, 168)
        Me.txtadd2.Name = "txtadd2"
        Me.txtadd2.Size = New System.Drawing.Size(136, 20)
        Me.txtadd2.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label1.Location = New System.Drawing.Point(159, -8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(394, 55)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "   Employee Details"
        '
        'txtadd1
        '
        Me.txtadd1.Location = New System.Drawing.Point(113, 121)
        Me.txtadd1.Name = "txtadd1"
        Me.txtadd1.Size = New System.Drawing.Size(136, 20)
        Me.txtadd1.TabIndex = 3
        '
        'btnexit
        '
        Me.btnexit.BackColor = System.Drawing.Color.Cyan
        Me.btnexit.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(379, 381)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 40)
        Me.btnexit.TabIndex = 20
        Me.btnexit.Text = "EXIT"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'btndelete
        '
        Me.btndelete.BackColor = System.Drawing.Color.Cyan
        Me.btndelete.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(289, 381)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(84, 40)
        Me.btndelete.TabIndex = 19
        Me.btndelete.Text = "DELETE"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'btnedit
        '
        Me.btnedit.BackColor = System.Drawing.Color.Cyan
        Me.btnedit.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnedit.Location = New System.Drawing.Point(208, 381)
        Me.btnedit.Name = "btnedit"
        Me.btnedit.Size = New System.Drawing.Size(75, 40)
        Me.btnedit.TabIndex = 18
        Me.btnedit.Text = "EDIT"
        Me.btnedit.UseVisualStyleBackColor = False
        '
        'btnsave
        '
        Me.btnsave.BackColor = System.Drawing.Color.Cyan
        Me.btnsave.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(127, 381)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 40)
        Me.btnsave.TabIndex = 16
        Me.btnsave.Text = "SAVE"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'btnadd
        '
        Me.btnadd.BackColor = System.Drawing.Color.Cyan
        Me.btnadd.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(46, 381)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 40)
        Me.btnadd.TabIndex = 15
        Me.btnadd.Text = "ADD"
        Me.btnadd.UseVisualStyleBackColor = False
        '
        'lbljd
        '
        Me.lbljd.AutoSize = True
        Me.lbljd.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbljd.Location = New System.Drawing.Point(287, 310)
        Me.lbljd.Name = "lbljd"
        Me.lbljd.Size = New System.Drawing.Size(75, 18)
        Me.lbljd.TabIndex = 13
        Me.lbljd.Text = "Join Date"
        '
        'lblsal
        '
        Me.lblsal.AutoSize = True
        Me.lblsal.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsal.Location = New System.Drawing.Point(287, 265)
        Me.lblsal.Name = "lblsal"
        Me.lblsal.Size = New System.Drawing.Size(94, 18)
        Me.lblsal.TabIndex = 12
        Me.lblsal.Text = "Basic Salary"
        '
        'lbldesig
        '
        Me.lbldesig.AutoSize = True
        Me.lbldesig.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldesig.Location = New System.Drawing.Point(287, 219)
        Me.lbldesig.Name = "lbldesig"
        Me.lbldesig.Size = New System.Drawing.Size(93, 18)
        Me.lbldesig.TabIndex = 11
        Me.lbldesig.Text = "Designation"
        '
        'lbldept
        '
        Me.lbldept.AutoSize = True
        Me.lbldept.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldept.Location = New System.Drawing.Point(287, 171)
        Me.lbldept.Name = "lbldept"
        Me.lbldept.Size = New System.Drawing.Size(91, 18)
        Me.lbldept.TabIndex = 10
        Me.lbldept.Text = "Department"
        '
        'lbldob
        '
        Me.lbldob.AutoSize = True
        Me.lbldob.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldob.Location = New System.Drawing.Point(286, 127)
        Me.lbldob.Name = "lbldob"
        Me.lbldob.Size = New System.Drawing.Size(50, 18)
        Me.lbldob.TabIndex = 9
        Me.lbldob.Text = "D.O.B"
        '
        'lblmobile
        '
        Me.lblmobile.AutoSize = True
        Me.lblmobile.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmobile.Location = New System.Drawing.Point(287, 72)
        Me.lblmobile.Name = "lblmobile"
        Me.lblmobile.Size = New System.Drawing.Size(84, 18)
        Me.lblmobile.TabIndex = 8
        Me.lblmobile.Text = "Mobile No."
        '
        'lblphone
        '
        Me.lblphone.AutoSize = True
        Me.lblphone.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblphone.Location = New System.Drawing.Point(287, 29)
        Me.lblphone.Name = "lblphone"
        Me.lblphone.Size = New System.Drawing.Size(82, 18)
        Me.lblphone.TabIndex = 7
        Me.lblphone.Text = "Phone No."
        '
        'lblcity
        '
        Me.lblcity.AutoSize = True
        Me.lblcity.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcity.Location = New System.Drawing.Point(30, 215)
        Me.lblcity.Name = "lblcity"
        Me.lblcity.Size = New System.Drawing.Size(35, 18)
        Me.lblcity.TabIndex = 4
        Me.lblcity.Text = "City"
        '
        'lbladd2
        '
        Me.lbladd2.AutoSize = True
        Me.lbladd2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd2.Location = New System.Drawing.Point(27, 171)
        Me.lbladd2.Name = "lbladd2"
        Me.lbladd2.Size = New System.Drawing.Size(86, 18)
        Me.lbladd2.TabIndex = 3
        Me.lbladd2.Text = "Emp. Add 2"
        '
        'lbladd1
        '
        Me.lbladd1.AutoSize = True
        Me.lbladd1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd1.Location = New System.Drawing.Point(27, 124)
        Me.lbladd1.Name = "lbladd1"
        Me.lbladd1.Size = New System.Drawing.Size(86, 18)
        Me.lbladd1.TabIndex = 2
        Me.lbladd1.Text = "Emp. Add 1"
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblname.Location = New System.Drawing.Point(24, 75)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(87, 18)
        Me.lblname.TabIndex = 1
        Me.lblname.Text = "Emp. Name"
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblid.Location = New System.Drawing.Point(27, 33)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(62, 18)
        Me.lblid.TabIndex = 0
        Me.lblid.Text = "Emp. ID"
        '
        'lblpin
        '
        Me.lblpin.AutoSize = True
        Me.lblpin.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpin.Location = New System.Drawing.Point(30, 310)
        Me.lblpin.Name = "lblpin"
        Me.lblpin.Size = New System.Drawing.Size(73, 18)
        Me.lblpin.TabIndex = 6
        Me.lblpin.Text = "Pin Code"
        '
        'grpbox
        '
        Me.grpbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.grpbox.Controls.Add(Me.Button1)
        Me.grpbox.Controls.Add(Me.ComboBox1)
        Me.grpbox.Controls.Add(Me.dtp2)
        Me.grpbox.Controls.Add(Me.dtp1)
        Me.grpbox.Controls.Add(Me.cmbstate)
        Me.grpbox.Controls.Add(Me.txtbsal)
        Me.grpbox.Controls.Add(Me.txtmobile)
        Me.grpbox.Controls.Add(Me.txtphone)
        Me.grpbox.Controls.Add(Me.txtpin)
        Me.grpbox.Controls.Add(Me.txtcity)
        Me.grpbox.Controls.Add(Me.txtname)
        Me.grpbox.Controls.Add(Me.cmbdesig)
        Me.grpbox.Controls.Add(Me.cmbdept)
        Me.grpbox.Controls.Add(Me.txtadd2)
        Me.grpbox.Controls.Add(Me.txtadd1)
        Me.grpbox.Controls.Add(Me.btnexit)
        Me.grpbox.Controls.Add(Me.btndelete)
        Me.grpbox.Controls.Add(Me.btnedit)
        Me.grpbox.Controls.Add(Me.btnsave)
        Me.grpbox.Controls.Add(Me.btnadd)
        Me.grpbox.Controls.Add(Me.lbljd)
        Me.grpbox.Controls.Add(Me.lblsal)
        Me.grpbox.Controls.Add(Me.lbldesig)
        Me.grpbox.Controls.Add(Me.lbldept)
        Me.grpbox.Controls.Add(Me.lbldob)
        Me.grpbox.Controls.Add(Me.lblmobile)
        Me.grpbox.Controls.Add(Me.lblphone)
        Me.grpbox.Controls.Add(Me.lblpin)
        Me.grpbox.Controls.Add(Me.lblstate)
        Me.grpbox.Controls.Add(Me.lblcity)
        Me.grpbox.Controls.Add(Me.lbladd2)
        Me.grpbox.Controls.Add(Me.lbladd1)
        Me.grpbox.Controls.Add(Me.lblname)
        Me.grpbox.Controls.Add(Me.lblid)
        Me.grpbox.Location = New System.Drawing.Point(52, 51)
        Me.grpbox.Name = "grpbox"
        Me.grpbox.Size = New System.Drawing.Size(568, 446)
        Me.grpbox.TabIndex = 7
        Me.grpbox.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Cyan
        Me.Button1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(460, 381)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 40)
        Me.Button1.TabIndex = 21
        Me.Button1.Text = "SHOW"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(113, 29)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(136, 21)
        Me.ComboBox1.TabIndex = 1
        '
        'lblstate
        '
        Me.lblstate.AutoSize = True
        Me.lblstate.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstate.Location = New System.Drawing.Point(30, 262)
        Me.lblstate.Name = "lblstate"
        Me.lblstate.Size = New System.Drawing.Size(45, 18)
        Me.lblstate.TabIndex = 5
        Me.lblstate.Text = "State"
        '
        'emplyoees_details
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(672, 524)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grpbox)
        Me.Name = "emplyoees_details"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "petrol manage- emplyoeesdetails"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.grpbox.ResumeLayout(False)
        Me.grpbox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dtp2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtp1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmbstate As System.Windows.Forms.ComboBox
    Friend WithEvents txtbsal As System.Windows.Forms.TextBox
    Friend WithEvents txtmobile As System.Windows.Forms.TextBox
    Friend WithEvents txtphone As System.Windows.Forms.TextBox
    Friend WithEvents txtpin As System.Windows.Forms.TextBox
    Friend WithEvents txtcity As System.Windows.Forms.TextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents cmbdesig As System.Windows.Forms.ComboBox
    Friend WithEvents cmbdept As System.Windows.Forms.ComboBox
    Friend WithEvents txtadd2 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtadd1 As System.Windows.Forms.TextBox
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents btnedit As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents lbljd As System.Windows.Forms.Label
    Friend WithEvents lblsal As System.Windows.Forms.Label
    Friend WithEvents lbldesig As System.Windows.Forms.Label
    Friend WithEvents lbldept As System.Windows.Forms.Label
    Friend WithEvents lbldob As System.Windows.Forms.Label
    Friend WithEvents lblmobile As System.Windows.Forms.Label
    Friend WithEvents lblphone As System.Windows.Forms.Label
    Friend WithEvents lblcity As System.Windows.Forms.Label
    Friend WithEvents lbladd2 As System.Windows.Forms.Label
    Friend WithEvents lbladd1 As System.Windows.Forms.Label
    Friend WithEvents lblname As System.Windows.Forms.Label
    Friend WithEvents lblid As System.Windows.Forms.Label
    Friend WithEvents lblpin As System.Windows.Forms.Label
    Friend WithEvents grpbox As System.Windows.Forms.GroupBox
    Friend WithEvents lblstate As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
